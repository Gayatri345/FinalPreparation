package puzzle;

public class Display {
    Display() {
        System.out.println("will display");
    }

    void show() {
        System.out.println("displaying");
    }
}
