package puzzle;

public class Board {
    Board() {
        System.out.println("board ready");
    }

    // array or list of filled up positions
}
